package aDatos_ej6;

import java.io.File;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce el nombre del directorio");
		String directorio = teclado.nextLine();
		
		System.out.println("Introduce la extension");
		String extension = teclado.nextLine();
		
		File file = new File(directorio);
		Filtro ext = new Filtro(extension);
		
		for(File archivo : file.listFiles()) {
			
			if( ext.accept(archivo)) {
				System.out.println(archivo.getName());
			}
		}


	}

}
