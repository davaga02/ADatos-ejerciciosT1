package aDatos_ej7;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String extension;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce el nombre del directorio");
		String directorio = teclado.next();
	
		
		System.out.println("Introduce el numero de extensiones que quieres introducir");
		int numExt = teclado.nextInt();
		
		
		System.out.println("Introduce las extensiones");
	
		
		String[] extensiones = new String[numExt];
		
		for(int i = 0; i < extensiones.length; i++) {
			
			extension = teclado.next();
			
			extensiones[i] = extension;
			
		}
		
		File file = new File(directorio);
		Filtro ext = new Filtro(extensiones);
		
		for(File archivo : file.listFiles()) {
			if( ext.accept(archivo)) {
				System.out.println(archivo.getName());
			}
		}


	}

}
