package aDatos_ej7;

import java.io.File;
import java.io.FileFilter;

public class Filtro implements FileFilter{
private String[] extension;
	
	public Filtro (String[] extension) {
		
		this.extension = extension;
	}

	@Override
	public boolean accept(File pathname) {
		// TODO Auto-generated method stub
		
		for(int i = 0; i < extension.length; i++ ) {
			
			if(pathname.getName().endsWith(extension[i])) {
				return true;
			}
		}
		
		return false;
	}
}