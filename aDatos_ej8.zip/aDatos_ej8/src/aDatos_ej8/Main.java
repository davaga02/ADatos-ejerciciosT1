package aDatos_ej8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	
	public static void copiarYBorrar (String nombreFichero) {
		
		File ficheroOriginal = new File(nombreFichero);
		
		String directorio = ficheroOriginal.getParent();
		String nombreFicheroOriginal = ficheroOriginal.getName();
		
		File ficheroCopia = new File(directorio, "copia_" + nombreFichero);
		
		try(FileReader fr = new FileReader(ficheroOriginal); //Lee el fichero
			BufferedReader br = new BufferedReader(fr); //Lee linea a linea
			FileWriter fw = new FileWriter(ficheroCopia);) //Copia lo que se ha leido en el fichero original
				
			{
			
			System.out.println("Copiando " + nombreFicheroOriginal + " en " + ficheroCopia);
			
			
			String linea;
			while((linea = br.readLine()) != null) {
				
				fw.write(linea);
				System.out.println("Linea copiada correctamente");
				
			} //mientras la linea que lea no sea null que escriba la linea
			
			System.out.println("Copia realizada correctamente en " + ficheroCopia.getName());
			
		}catch(IOException e) {
			
			System.out.println("Error durante la copia del fichero");
			return;
			
		}
		
		System.out.println("Eliminando fichero creado " + ficheroCopia);
		if(ficheroCopia.delete()) {
			System.out.println("Fichero borrado correctamente");
		}else {
			System.out.println("Error en la eliminación del fichero "+ ficheroCopia);
		}

		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Dime el nombre del fichero");
		String nombreFichero = teclado.next();
		
		copiarYBorrar(nombreFichero);
		
		
	}

}
