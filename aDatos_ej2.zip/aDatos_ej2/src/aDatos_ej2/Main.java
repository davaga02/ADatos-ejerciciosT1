package aDatos_ej2;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		
		
		System.out.println("Introduce el nombre del directorio");
		String directorio = teclado.nextLine();
		
		File file = new File(directorio);
		
		System.out.println(file.exists());
		System.out.println(file.isFile());
		System.out.println(file.isDirectory());
		System.out.println(file.isAbsolute());
		System.out.println(file.canRead());
		System.out.println(file.canWrite());
		System.out.println(file.getName());
		System.out.println(file.getAbsolutePath());
		System.out.println(file.getPath());
		
	
	}

}
